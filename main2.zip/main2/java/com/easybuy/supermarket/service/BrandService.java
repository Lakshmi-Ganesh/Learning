package com.easybuy.supermarket.service;

import java.util.List;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;

public interface BrandService {

	public List<brand> getAllBrands();
	
	public BrandResponsePattern newBrand(brand b, Long id);

	
	
}
