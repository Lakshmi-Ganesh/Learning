package com.easybuy.supermarket.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="product")
public class product {
	@Id
	@Column(name="product_id")
	private String productId;
	
	@Column(name="product_name")
	private String productName;

//	@ManyToOne()
//
// private brand brands;
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
}
