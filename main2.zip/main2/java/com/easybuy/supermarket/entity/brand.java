package com.easybuy.supermarket.entity;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="brand")
public class brand {

	@Id
	@Column(name="brand_id")
	private Long brandId;
	
	@Column(name="brand_name")
	private String brandName;

	public Long getBrandId() {
		return brandId;
	}

	
	
	
//	@OneToMany(mappedBy="brands")
//	private List<product> products = new ArrayList<product>();
//	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	private category categories;

	public String getBrandName() {
		return brandName;
	}




	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}




	public category getCategories() {
		return categories;
	}




	public void setCategories(category categories) {
		this.categories = categories;
	}




	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}




	@Override
	public String toString() {
		return "brand [brandId=" + brandId + ", brandName=" + brandName + ", categories=" + categories + "]";
	}




	
	

	
}
