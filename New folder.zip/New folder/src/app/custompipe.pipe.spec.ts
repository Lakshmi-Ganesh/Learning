import { CustompipePipe } from './custompipe.pipe';

describe('CustompipePipe', () => {
  it('create an instance', () => {
    const pipe = new CustompipePipe();
    expect(pipe).toBeTruthy();
  });
});
