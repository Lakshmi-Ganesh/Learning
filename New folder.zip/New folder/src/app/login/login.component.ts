import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationCancel } from '@angular/router';
import{loginVO} from '../../dto/loginVO';
import {UserRegServicesComponent} from '../services/UserReg.services.component';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

loginvo: loginVO = new loginVO();
  constructor(private router: Router, private route: ActivatedRoute,private loginService: UserRegServicesComponent) { }

  ngOnInit() {
  }

navigateToSignUpPage() {

this.router.navigateByUrl('/signup');

}


nextPage(){


const userlogin: any = new Object();
userlogin['firstName'] = this.loginvo.userName;
userlogin['password'] = this.loginvo.password;
console.log(userlogin);
this.loginService.UserLoginInfo(userlogin).then(data=>{

console.log(data);
console.log(data.headers.get('authorization'));
sessionStorage.setItem('token',data.headers.get('authorization'));

})

  this.router.navigateByUrl('/dashboard');

}

}
