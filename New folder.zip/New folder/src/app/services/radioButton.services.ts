import { Component, OnInit,Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
 import{Response} from '@angular/http';
import {REQUEST_HEADER} from '../../constants/constants';
// import {HEADER} from '../../constants/constants';
@Component({
  selector: 'app-radioButtonServices',

})
@Injectable()
export class RadioButtonServices implements OnInit {

  constructor(private httpclient: HttpClient) { }

  ngOnInit() {
  }


getUrl(metadataJsonName){

    const url = this.getmetadataurl(metadataJsonName);
    return this.httpclient.get(url).toPromise().then((response:Response)=>response).catch(this.handleError);
}



private getmetadataurl(metadataName){

switch(metadataName){
 case 'FeMale':{
return './metadata/'+metadataName+'.json';

 }

 case 'samplepipe':{

  return './metadata/'+metadataName+ '.json';
 }

}

}

private handleError(error: any): Promise<any> {
  console.error('An error occurred', error);
  console.log('ERROR' + error);
  return Promise.reject(error.message || error);
}
}
