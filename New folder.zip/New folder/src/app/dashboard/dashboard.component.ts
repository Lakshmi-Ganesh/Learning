import { Component, OnInit } from '@angular/core';
import {RadioButtonServices} from  '../services/radioButton.services';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
public productList: Array<Object> = new Array<Object>();
public searchList: Boolean = false;
  constructor(private radioservice: RadioButtonServices) { }

  ngOnInit() {

this.radioservice.getUrl('samplepipe').then(data=>{

  console.log(data);
this.productList = data;
// console.log(this.productList['product'][0]['productName']);
console.log(this.productList[0]['productName']);
})


  }


public searchProducts(){

this.searchList = true;



}

clearProducts(){
  
  this.searchList = false;
}

}
