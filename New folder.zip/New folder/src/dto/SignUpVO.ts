export class SignUpVO {
public firstName: String;
public lastName: String;
public password: String;
public confirmPassword: String;
public emailId: String;
public gender: String;
public dateOfBirth: String;


}
