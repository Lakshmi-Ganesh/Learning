import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custompipe'
})
export class CustompipePipe implements PipeTransform {

  // transform(value: any, args?: any): any {
    transform(productList: any, search?: any): any {
    console.log(productList)
    console.log(search);
    if(productList && productList.length){

return productList.filter(value =>{

  if(search && value.productName.toLowerCase().indexOf(search.toLowerCase())=== -1){

    return false;
  }
  else {

    return true;
  }
})

    }
    // else {

    //   return productList;
    // }
    else {

      return [];
    }
  }

}
