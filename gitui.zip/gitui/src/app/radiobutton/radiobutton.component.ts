import { Component, OnInit , Input, Output,EventEmitter,Inject,Optional,ViewChild, OnChanges} from '@angular/core';
import {RadioButtonServices} from '../services/radioButton.services';
import { ElementBase } from '../../accessor/element.base';
import {
  NgModel,
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  NG_ASYNC_VALIDATORS,
} from '@angular/forms';
@Component({
  selector: 'app-radiobutton',
  templateUrl: './radiobutton.component.html',
  styleUrls: ['./radiobutton.component.css'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: RadiobuttonComponent, multi: true }
  ]
})


export class RadiobuttonComponent extends ElementBase<string> implements OnInit, OnChanges {
 
  // protected model: NgModel;
 

 
  @Input()
  public label: any;

  @Input()
  public type: String='radio';

  // @Input()
  // public name: String;

  @Input()
  public DataArray: Array<Object>;
  
  @ViewChild(NgModel)
  model: NgModel;

  @Input()
  public id: any;

  @Input()
  public radioName: any;

 @Input()
  public value: any;

@Input()
public dataList: Array<Object> = new Array<Object>();

  @Output() public changeevent = new EventEmitter<Object>();

  @Output() public messageevent = new EventEmitter<Object>();

  constructor(private radioservice: RadioButtonServices, @Optional()
  @Inject(NG_VALIDATORS)
  validators: Array<any>,
  @Optional()
  @Inject(NG_ASYNC_VALIDATORS)
  asyncValidators: Array<any>) {super(validators, asyncValidators); }

  ngOnInit() {
   
if(this.radioName){

this.getRadioNames(this.radioName);

}

  }



public getRadioNames(metadataName){

if(metadataName){

 this.radioservice.getUrl(metadataName).then(data=>{

this.DataArray = this.convertToDataArray(metadataName,data);

// this.messageevent.emit(this.DataArray);
 })


}

}


convertToDataArray(metadataName,dataarray){

switch(metadataName){

case 'FeMale':{

const dtArray:Array<Object> = new Array<Object>();
for(const data of dataarray){
const obj: Object = new Object();
obj['code'] = data['code'];
obj['description'] = data['description'];
dtArray.push(obj);

}
sessionStorage.setItem('FeMale',JSON.stringify(dataarray));
return dtArray;
}

}
}



ngOnChanges(changes: any) {
 
  if(this.radioName){

    this.getRadioNames(this.radioName);
    
    }
 }







  public radioBlur(bool:Boolean){


    this.changeevent.emit(this.value);
    console.log(this.value);
return true;
  }



  










}
