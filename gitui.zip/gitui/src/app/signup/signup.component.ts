import { UserRegServicesComponent } from './../services/UserReg.services.component';
import { Component, OnInit } from '@angular/core';
import {SignUpVO} from 'src/dto/SignUpVO';
import {RadioButtonServices} from '../services/radioButton.services';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
public signupvo: SignUpVO = new SignUpVO();
public valmsg: Boolean= false;
public validationMessage: any;
  constructor(private userregService: UserRegServicesComponent,private radioservice: RadioButtonServices) { }

  ngOnInit() {

    // this.signupvo.gender = 'F';
    this.radioservice.getUrl('FeMale').then(data=>{

      console.log(data);
    })

  }

public checkpwdmatch(confirmpwd: String){
alert('hi inside if');
if(confirmpwd === this.signupvo.password){
  alert('match alert no need to worry');
this.validationMessage = '';
// this.valmsg = false;

} else {
  
this.validationMessage = 'password does not match';
alert(this.validationMessage);
  // this.valmsg = true;
}

  }


  getValues(a){

alert(a);

  }

  func(){

console.log(this.signupvo.gender);

  }

  sendRequest() {
    const requestObj: any = new Object();
    requestObj['firstName'] = this.signupvo.firstName;
    requestObj['lastName'] = this.signupvo.lastName;
    requestObj['password'] = this.signupvo.password;
    requestObj['confirmPassword'] = this.signupvo.confirmPassword;
    requestObj['emailId'] = this.signupvo.emailId;
    requestObj['gender'] = this.signupvo.gender;
    requestObj['dateOfBirth'] = this.signupvo.dateOfBirth;
    console.log(requestObj);

this.userregService.UserRegInfo(requestObj).then(data => {
console.log(data);
}).catch(error => {

  console.log('Error Occured' + error);
});

  }
}
