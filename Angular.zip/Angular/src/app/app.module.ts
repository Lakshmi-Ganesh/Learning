import { routing } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { TextboxComponent } from './textbox/textbox.component';
import {UserRegServicesComponent} from './services/UserReg.services.component';
import { RadiobuttonComponent } from './radiobutton/radiobutton.component';
import {RadioButtonServices} from './services/radioButton.services';
import { JwtInterceptorComponent } from './jwt-interceptor/jwt-interceptor.component';
import { DashboardComponent } from './dashboard/dashboard.component'

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    TextboxComponent,
    RadiobuttonComponent,
    JwtInterceptorComponent,
    DashboardComponent


  ],
  imports: [
    BrowserModule,
    routing,
    FormsModule,
    ReactiveFormsModule,

    HttpClientModule
  ],
  providers: [UserRegServicesComponent,RadioButtonServices,{provide: HTTP_INTERCEPTORS, useClass: JwtInterceptorComponent, multi:true},],
  bootstrap: [AppComponent]
})
export class AppModule { }
