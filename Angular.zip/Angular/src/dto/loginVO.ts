export class loginVO {
public userName: String;

public password: String;



}
