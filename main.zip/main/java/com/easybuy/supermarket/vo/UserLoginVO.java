package com.easybuy.supermarket.vo;

public class UserLoginVO {

//private String userName;
//	
//	private String password;
//
//	public String getUserName() {
//		return userName;
//	}
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	@Override
//	public String toString() {
//		return "UserLogin [userName=" + userName + ", password=" + password + "]";
//	}
	

	
private String firstName;
	
	private String password;

	public String getfirstName() {
		return firstName;
	}

	public void setUserName(String firstName) {
		this.firstName = firstName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "UserLogin [firstName=" + firstName + ", password=" + password + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
