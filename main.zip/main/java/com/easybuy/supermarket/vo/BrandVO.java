package com.easybuy.supermarket.vo;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.easybuy.supermarket.entity.category;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonView;



public class BrandVO {

	@JsonProperty("brandId")
	private Long brandId;
	
	@JsonProperty("brandName")
	private String brandName;

	public Long getBrandId() {
		return brandId;
	}

	@JsonIgnore()
	private category categories;
	
	//@OneToMany(mappedBy="brands",fetch = FetchType.LAZY)
	//@JsonIgnore
	private List<ModelVO> models = new ArrayList<ModelVO>();



	public String getBrandName() {
		return brandName;
	}




	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}


	public List<ModelVO> getModels() {
		return models;
	}




	public void setModels(List<ModelVO> models) {
		this.models = models;
	}





	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}




	public category getCategories() {
		return categories;
	}




	public void setCategories(category categories) {
		this.categories = categories;
	}




	@Override
	public String toString() {
		return "BrandVO [brandId=" + brandId + ", brandName=" + brandName + ", models=" + models + "]";
	}




	






	
	

	
}
