package com.easybuy.supermarket.jwtConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.easybuy.supermarket.repository.UserRepository;

@Component
public class CustomUserDetailService implements UserDetailsService{

	 @Autowired
	 private UserRepository  userreg;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		try {
			return userreg.findByUserName(username);
			
		}catch(UsernameNotFoundException e) {
			throw new UsernameNotFoundException("User Not found");
		}
		
	}

}
