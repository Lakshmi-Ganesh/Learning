package com.easybuy.supermarket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.easybuy.supermarket.entity.category;

public interface CategoryInterface extends JpaRepository<category,Long> {
	
	

}
