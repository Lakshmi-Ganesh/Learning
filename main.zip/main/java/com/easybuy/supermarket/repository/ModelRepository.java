package com.easybuy.supermarket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.easybuy.supermarket.entity.model;

public interface ModelRepository extends JpaRepository<model,Long> {

}
