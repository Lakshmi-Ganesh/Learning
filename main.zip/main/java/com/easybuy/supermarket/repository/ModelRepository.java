package com.easybuy.supermarket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.model;
@Repository
public interface ModelRepository extends JpaRepository<model,Long> {
	
	
	//@Query("SELECT u FROM model u WHERE u.brandId = :brandId")
	
	public List<model> findByBrands_brandId(@Param("brandId") Long brandid);
	
	
	

}
