package com.easybuy.supermarket.responsePattern;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.vo.BrandVO;

public class BrandResponsePattern {

private String status;
	
	private String body;
	
	private BrandVO Brands;
	
	//private category cats;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public BrandVO getBrands() {
		return Brands;
	}

	public void setBrands(BrandVO brands) {
		Brands = brands;
	}



//	public category getCats() {
//		return cats;
//	}
//
//	public void setCats(category cats) {
//		this.cats = cats;
//	}



}
