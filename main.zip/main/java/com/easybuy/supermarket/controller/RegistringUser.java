package com.easybuy.supermarket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.easybuy.supermarket.entity.UserLogin;
import com.easybuy.supermarket.entity.UserRegistration;
//import com.easybuy.supermarket.jwtConfig.JwtTokenProvider;
import com.easybuy.supermarket.responsePattern.ResponsePattern;
import com.easybuy.supermarket.service.UserRegistrationService;
@RestController
@RequestMapping("/userRegistration")
public class RegistringUser {
	
	@Autowired
	UserRegistrationService userRegistration;
	
//	@Autowired
//	private JwtTokenProvider JwtTokenprovider;
	
	@PostMapping(value="/Registration")
	private ResponseEntity<ResponsePattern> registerUser(@RequestBody UserRegistration user){
		System.out.println(user);

			ResponsePattern respat = userRegistration.registerUser(user);
			System.out.println(respat);
			return new ResponseEntity<ResponsePattern>(respat,HttpStatus.OK);
			
			
		}
	
	@PostMapping(value="/login")
	private ResponseEntity<ResponsePattern> loginUser(@RequestBody UserLogin login){
		System.out.println(login);
		
		  HttpHeaders header = new HttpHeaders();
		    
//		    String token = JwtTokenprovider.createToken(login.getfirstName());
//		    System.out.println("hey"+token);
//		     header.set("Authorization", token);
//		     System.out.println(token);
		     ResponsePattern response = userRegistration.loginUser(login);
			return ResponseEntity.ok().headers(header).body(response);
		
		
	}

	}
	


