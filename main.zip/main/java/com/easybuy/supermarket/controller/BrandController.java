package com.easybuy.supermarket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;
import com.easybuy.supermarket.responsePattern.ResponsePattern;
import com.easybuy.supermarket.service.BrandService;
import com.easybuy.supermarket.vo.BrandVO;
@RequestMapping(value="/brands")
@RestController
public class BrandController {

	@Autowired
	BrandService brandService;
	
	
	
	@GetMapping(value="/all")
	private List<BrandVO> getBrands(){
		
		return brandService.getAllBrands();
	}
	
	
	@PostMapping(value="/savebrand/{id}")
	private ResponseEntity<BrandResponsePattern> saveBrands(@RequestBody BrandVO b ,@PathVariable  Long id){

		
		System.out.println(b);
		System.out.println(id);
		BrandResponsePattern brsp = brandService.newBrand(b,id);
		return new ResponseEntity<BrandResponsePattern>(brsp, HttpStatus.OK);
		
		
	}

}
