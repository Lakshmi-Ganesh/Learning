package com.easybuy.supermarket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.entity.model;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;
import com.easybuy.supermarket.responsePattern.ModelResponsePattern;
import com.easybuy.supermarket.service.ModelService;
import com.easybuy.supermarket.vo.ModelVO;
@RequestMapping(value="/model")
@RestController
public class ModelController {

@Autowired
ModelService modelService;

@GetMapping(value="/all")
public List<model> getallModels() {
	
	return modelService.getAllModels();
}
	
@PostMapping(value="/saveModel/{id}")	
public ResponseEntity<ModelResponsePattern> saveModel(@RequestBody ModelVO mod, @PathVariable Long id, @RequestParam Long brandId){
	
brand b = new brand();
b.setBrandId(brandId);

category c = new category();
c.setCategoryId(id);


ModelResponsePattern mrp= modelService.addModel(id, brandId, mod);
return new ResponseEntity<ModelResponsePattern>(mrp,HttpStatus.OK);

}
@GetMapping(value="/getModel/{id}")
public List<model> getBrandModel(@PathVariable Long id){

return modelService.getBrandModel(id);
}
}


