package com.easybuy.supermarket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;
import com.easybuy.supermarket.responsePattern.CategoryResponsePattern;
import com.easybuy.supermarket.service.CategoryService;
import com.easybuy.supermarket.vo.CategoryVO;

@RequestMapping(value="/category")
@RestController
public class CategoryController {
	
@Autowired
CategoryService categoryService;

@GetMapping(value="/all")
public List<CategoryVO> getAllCategories(){
	
	return categoryService.getAllCategories();
}


@PostMapping(value="/savecategory")
private ResponseEntity<CategoryResponsePattern> saveCategory(@RequestBody CategoryVO c){
	
	
	CategoryResponsePattern crp = categoryService.catPat(c);
	return new ResponseEntity<CategoryResponsePattern>(crp, HttpStatus.OK);
	
	
}


}
