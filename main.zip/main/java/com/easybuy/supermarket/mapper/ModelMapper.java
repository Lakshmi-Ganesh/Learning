package com.easybuy.supermarket.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.entity.model;
import com.easybuy.supermarket.vo.CategoryVO;
import com.easybuy.supermarket.vo.ModelVO;
@Component
public class ModelMapper {

	public void fromModelToModelVO(model mod , ModelVO modvo) {
		
		try {
			
			BeanUtils.copyProperties(mod,modvo);
			
		} catch(Exception e) {
		
	}


	}

	public void fromModlVOToModel(ModelVO modvo,model mod) {
		
		try {
			
			BeanUtils.copyProperties(modvo,mod);
			
		} catch(Exception e) {
		
	}


	}


}
