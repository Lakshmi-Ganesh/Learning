package com.easybuy.supermarket.mapper;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Component;

import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.entity.model;
import com.easybuy.supermarket.vo.CategoryVO;
import com.easybuy.supermarket.vo.ModelVO;

@Component
public class ModelMapper {

	 public void fromModelToModelVO(model mod, ModelVO modelvo) {
	        try {
	            BeanUtils.copyProperties(modelvo, mod);
	        } catch (Exception e) {

	        }
	    }
	 
	 public void fromModelVOToModel(ModelVO modelvo,model mod) {
	        try {
	            BeanUtils.copyProperties( mod,modelvo);
	        } catch (Exception e) {

	        }
	    }
	
}
