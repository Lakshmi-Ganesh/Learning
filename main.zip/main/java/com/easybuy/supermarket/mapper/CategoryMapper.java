package com.easybuy.supermarket.mapper;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Component;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.vo.BrandVO;
import com.easybuy.supermarket.vo.CategoryVO;
@Component
public class CategoryMapper {

	 public void fromCategoryToCategoryVO(category cat, CategoryVO categoryVO) {
	        try {
	            BeanUtils.copyProperties(categoryVO, cat);
	        } catch (Exception e) {

	        }
	    }
	 
	 public void fromCategoryVOToCategory(CategoryVO categoryVO,category cat) {
	        try {
	            BeanUtils.copyProperties( cat,categoryVO);
	        } catch (Exception e) {

	        }
	    }
	
}
