package com.easybuy.supermarket.mapper;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.vo.CategoryVO;
@Component
public class CategoryMapper {

public void fromCategoryToCategoryVO(category ct , CategoryVO catvo) {
	
	try {
		
		BeanUtils.copyProperties(ct,catvo);
		
	} catch(Exception e) {
	
}


}

public void fromCategoryVOToCategory(CategoryVO catvo,category ct  ) {
	
	try {
		
		BeanUtils.copyProperties(catvo,ct);
		
	} catch(Exception e) {
	
}


}

public void fromOptionalCategoryToCategoryVO(Optional<category> ct, CategoryVO categoryvo) {
try {
		
		BeanUtils.copyProperties(categoryvo,ct);
		
	} catch(Exception e) {
	
}
}

}