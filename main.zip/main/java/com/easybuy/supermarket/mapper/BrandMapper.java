package com.easybuy.supermarket.mapper;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Component;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.vo.BrandVO;

@Component
public class BrandMapper {

	  public void fromBrandToBrandVO(brand br, BrandVO brandVO) {
	        try {
	            BeanUtils.copyProperties(brandVO, br);
	        } catch (Exception e) {

	        }
	    }

	   
	     
	    public void fromBrandVOToBrand(BrandVO brandVO,  brand br) {
	        try {
	            BeanUtils.copyProperties(br, brandVO);
	        } catch (Exception e) {

	        }
	    
	
}
}