package com.easybuy.supermarket.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="product_info")

public class ProductInfo {

	@Id
	@Column(name="prod_id")
	private String prodId;
	
	@Column(name="product_name")
	private String prodName;
	
	@Column(name="brand")
	private String brand;
	
	@Column(name="category")
	private String category;
	
	
	@Column(name="sub_category")
	private String subcategory;

//	@ManyToOne()
//	private UserRegistration user;

	public String getProdId() {
		return prodId;
	}


	public void setProdId(String prodId) {
		this.prodId = prodId;
	}


	public String getProdName() {
		return prodName;
	}


	public void setProdName(String prodName) {
		this.prodName = prodName;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getSubcategory() {
		return subcategory;
	}


	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}


	
}
