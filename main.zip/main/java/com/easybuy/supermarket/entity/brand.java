package com.easybuy.supermarket.entity;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
@Table(name="brand")

public class brand {

	@Id
	@Column(name="brand_id")
	private Long brandId;
	
	@Column(name="brand_name")
	private String brandName;

	public Long getBrandId() {
		return brandId;
	}

	
	
	
	@OneToMany(mappedBy="brands",fetch = FetchType.LAZY)
	//@JsonIgnore
	private List<model> models = new ArrayList<model>();
	
//	@JoinColumn(name = "category_id", referencedColumnName = "category_Id")
	@ManyToOne()
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@JsonIgnore
	//@JsonView(brand.class)
	@JoinColumn(name = "category_id")
	private category categories;

	public String getBrandName() {
		return brandName;
	}




	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}




	public category getCategories() {
		return categories;
	}




	public void setCategories(category categories) {
		this.categories = categories;
	}




	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}




	









	
	

	
}
