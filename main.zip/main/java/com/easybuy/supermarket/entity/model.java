package com.easybuy.supermarket.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity

@Table(name="model")

public class model {

                @Id

                @Column(name="model_id")

                private Long modelId;

               @Column(name="model_Image")
               private String imgUrl;

                public String getImgUrl() {
				return imgUrl;
			}



			public void setImgUrl(String imgUrl) {
				this.imgUrl = imgUrl;
			}



				@Column(name="model_name")

                private String modelName;

 @JsonIgnore()

                @ManyToOne(fetch = FetchType.LAZY)

                @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

    private brand brands;

               

               

                public brand getBrands() {

                                return brands;

                }

 

                public void setBrands(brand brands) {

                                this.brands = brands;

                }

 

                public Long getModelId() {

                                return modelId;

                }

 

                public void setModelId(Long modelId) {

                                this.modelId = modelId;

                }

 

                public String getModelName() {

                                return modelName;

                }

 

                public void setModelName(String modelName) {

                                this.modelName = modelName;

                }

 

	
	
	
}
