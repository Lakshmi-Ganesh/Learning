package com.easybuy.supermarket.entity;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

@Table(name="category")

public class category {

               

                @Id

                @Column(name="category_id")

                private Long categoryId;

               

                @Column(name="category_name")

                private String categoryName;

 

               

//            @OneToMany(mappedBy="categories",fetch = FetchType.LAZY)

                @JsonIgnore

//            private List<brand> brands = new ArrayList<>();

               

                @OneToMany(mappedBy="categories",fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)

   

                private List<brand> brands = new ArrayList<>();

 

                public List<brand> getBrands() {

                                if(brands== null) {

                                               

                                                return new ArrayList<brand>();

                                }

                                return brands;

                }

 

                public void setBrands(List<brand> brands) {

                                this.brands = brands;

                }

 

               

 

 

                public Long getCategoryId() {

                                return categoryId;

                }

 

                public void setCategoryId(Long categoryId) {

                                this.categoryId = categoryId;

                }

 

                public String getCategoryName() {

                                return categoryName;

                }

 

                public void setCategoryName(String categoryName) {

                                this.categoryName = categoryName;

                }

 

               

 

               

 

               

 

               

 


}
