package com.easybuy.supermarket.service;

import java.util.List;

import com.easybuy.supermarket.entity.model;
import com.easybuy.supermarket.responsePattern.ModelResponsePattern;
import com.easybuy.supermarket.vo.ModelVO;

public interface ModelService {

	
	public List<model> getAllModels();
	
	public List<model> getBrandModel(Long brandId);
	
	public ModelResponsePattern addModel(Long catId,Long brandId, ModelVO modl);
	
	
}

