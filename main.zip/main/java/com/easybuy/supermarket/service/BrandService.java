package com.easybuy.supermarket.service;

import java.util.List;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;
import com.easybuy.supermarket.vo.BrandVO;

public interface BrandService {

	public List<BrandVO> getAllBrands();
	
	public BrandResponsePattern newBrand(BrandVO b, Long id);

	
	
}
