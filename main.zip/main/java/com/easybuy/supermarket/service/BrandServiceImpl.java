package com.easybuy.supermarket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.repository.BrandRepository;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;

@Service
public class BrandServiceImpl implements BrandService {

@Autowired
BrandRepository brandRepository;

@Override
public List<brand> getAllBrands() {
	// TODO Auto-generated method stub
	
	
	return brandRepository.findAll();
}

@Override
public BrandResponsePattern newBrand(brand bran) {
	// TODO Auto-generated method stub
	
	if(bran != null) {
		
	Long autoBrandId = System.currentTimeMillis();
	bran.setBrandId(autoBrandId);
	BrandResponsePattern brp = new BrandResponsePattern();
	brand brand1= brandRepository.saveAndFlush(bran);
	if(brand1 != null) {
		
		brp.setStatus("success");
		brp.setBody("Brand added successfully");
		brp.setBrands(brand1);
	}
	return brp;
		
	}
	
	else {
		BrandResponsePattern brp = new BrandResponsePattern();
		brp.setStatus("failed");
		brp.setBody("Brand failed");
		return brp;
		
		
	}
	
}	
	
	
	

}
