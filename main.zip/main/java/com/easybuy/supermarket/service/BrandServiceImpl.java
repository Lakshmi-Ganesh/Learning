package com.easybuy.supermarket.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.mapper.BrandMapper;
import com.easybuy.supermarket.repository.BrandRepository;
import com.easybuy.supermarket.repository.CategoryRepository;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;
import com.easybuy.supermarket.vo.BrandVO;

@Service
public class BrandServiceImpl implements BrandService {

	@Autowired

	BrandRepository brandRepository;

	 

	@Autowired

	CategoryRepository categoryrepository;

	 

	@Autowired

	BrandMapper brandMapper;

	 

	 

	@Override

	public List<BrandVO> getAllBrands() {

	               

	                List<BrandVO> brandVOs = new ArrayList<>();

	                List<brand> br = brandRepository.findAll();

	                br.forEach(bran ->{

	                                BrandVO brandvo = new BrandVO();

	                                brandMapper.fromBrandToBrandVO(bran, brandvo);

	                                brandVOs.add(brandvo);

	                });

	               

	                return brandVOs;

	}

	 

	 

	@Override

	public BrandResponsePattern newBrand(BrandVO bran, Long id) {

	                // TODO Auto-generated method stub

	                if(bran != null && id != null) {

	                               

	                                BrandResponsePattern brp = new BrandResponsePattern();

	                               

	                                category cat = categoryrepository.getOne(id);

	                               

	                                if(cat != null) {

	                                                brand br = new brand();

	                                                Long autoBrandId = System.currentTimeMillis();

	                                                bran.setBrandId(autoBrandId);

	                                                bran.setCategories(cat);

	                                                brandMapper.fromBrandVOToBrand(bran, br);

	                                                System.out.println(br);

//	                                            category cat1 = new category();

//	                                            cat1.getBrands().add(br);

	                                                                               

	                                                br= brandRepository.saveAndFlush(br);

	                                                System.out.println(br);

	                                                if(br != null) {

	                                                                BrandVO newbrandvo = new BrandVO();

	                                                                brandMapper.fromBrandToBrandVO(br, newbrandvo);

	                                                                brp.setStatus("success");

	                                                                brp.setBody("Brand added successfully");

	                                                          //      brp.setBrands(newbrandvo);

	                                                                //brp.setCats(ct);

	                                                } else {

	                                                                // BrandResponsePattern brp = new BrandResponsePattern();

	                                                               

	                                                                brp.setStatus("falied");

	                                                                brp.setBody("Something went wrong in the id. Please check the URL");

	                                                                return brp;

	                                                }

	                                               

	                                }

	                                return brp;

	                }

	                               

	                                else {

	                                                BrandResponsePattern brp1 = new BrandResponsePattern();

	                                                brp1.setStatus("failed");

	                                                brp1.setBody("Brand failed");

	                                                return brp1;

	                                               

	                                               

	                                }

	 

	                }

	               

	
	
	
	

}
