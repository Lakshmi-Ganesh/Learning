package com.easybuy.supermarket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.repository.BrandRepository;
import com.easybuy.supermarket.repository.CategoryRepository;
import com.easybuy.supermarket.responsePattern.BrandResponsePattern;

@Service
public class BrandServiceImpl implements BrandService {

@Autowired
BrandRepository brandRepository;

@Autowired 
CategoryRepository categoryrepository;

@Override
public List<brand> getAllBrands() {
	// TODO Auto-generated method stub
	
	
	return brandRepository.findAll();
}

@Override
public BrandResponsePattern newBrand(brand bran,Long id) {
	// TODO Auto-generated method stub
	
	if(bran != null && id!= null) {
		System.out.println("hi");
		BrandResponsePattern brp = new BrandResponsePattern();
	//category ct = categoryrepository.getOne(id);
    	Optional<category> ct = categoryrepository.findById(id);
	
	 System.out.println(ct.toString());
	
	if(ct.isPresent() ) {
	//	category cat = new category();
		//category catId = ct.get().getCategoryId();
		// category cat1 = cat.setCategoryId(catId);
		bran.setCategories(ct.get());
		System.out.println(bran);
	Long autoBrandId = System.currentTimeMillis();
	bran.setBrandId(autoBrandId);
	System.out.println(bran);
	System.out.println("hi 2");
	brand brand1= brandRepository.saveAndFlush(bran);
	
	
	System.out.println(brand1);
	if(brand1 != null) {
		
		brp.setStatus("success");
		brp.setBody("Brand added successfully");
		//brp.setBrands(brand1);
		//brp.setCats(ct);
	}
//	return brp;
		
	} 
	
	
	else {
		// BrandResponsePattern brp = new BrandResponsePattern();
		System.out.println("hi 3");
		brp.setStatus("falied");
		brp.setBody("Something went wrong in the id. Please check the URL");
		return brp;
	}
	
	
	return brp;
	}
	else {
		BrandResponsePattern brp = new BrandResponsePattern();
		brp.setStatus("failed");
		brp.setBody("Brand failed");
		return brp;
		
		
	}
	
}	
	
	
	

}
