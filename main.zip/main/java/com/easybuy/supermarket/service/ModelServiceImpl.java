package com.easybuy.supermarket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.entity.model;
import com.easybuy.supermarket.repository.BrandRepository;
import com.easybuy.supermarket.repository.CategoryRepository;
import com.easybuy.supermarket.repository.ModelRepository;
import com.easybuy.supermarket.responsePattern.ModelResponsePattern;

@Service
public class ModelServiceImpl implements ModelService {

@Autowired
ModelRepository modelRepo;
	
@Autowired
BrandRepository brandRepo;

@Autowired 
CategoryRepository catRepo;
	
	
	@Override
	public List<model> getAllModels() {
		// TODO Auto-generated method stub
		return modelRepo.findAll();
	}

	@Override
	public List<model> getBrandModel(Long brandId) {
		// TODO Auto-generated method stub
		if(brandId != null) {
		
			List<model> mod= (List<model>) modelRepo.findById(brandId).get();
			
			return mod;
		}
	return null;
	}

	@Override
	public ModelResponsePattern addModel(Long catId, Long brandId, model modl) {
		// TODO Auto-generated method stub
	
		if(modl != null && brandId !=null && catId != null) {
			
			System.out.println("hi");
			ModelResponsePattern mrp = new ModelResponsePattern();
	
			Optional<category> ct = catRepo.findById(catId);
		//	category ct = catRepo.getOne(catId);
			if(ct != null && ct.isPresent() ) {
				System.out.println("hi1");
			//	modl.setCategoryMod(ct);
				modl.setCategoryMod(ct.get());
			Optional<brand> br = brandRepo.findById(brandId); 
				
				if(br != null && br.isPresent()) {
					System.out.println("hi2");
					Long modelId = System.currentTimeMillis();
					
					modl.setBrands(br.get());
					modl.setModelId(modelId);
					model model1 = modelRepo.saveAndFlush(modl);
				if(model1 != null) {
					
					
					mrp.setBody("model added successfully");
					mrp.setStatus("Success");
					//mrp.setBrands(br);
					//mrp.setCats(ct);
				} else {
					mrp.setBody("model added failed");
					mrp.setStatus("Failed");
					
				}
				
				
				} else {
					
					mrp.setBody("model added failed - unable to retrieve brandId");
					mrp.setStatus("Failed");	
				}
			
				
			} else {
				
				mrp.setBody("model added failed - unable to retrieve categoryId");
				mrp.setStatus("Failed");
				
			}
		
			return mrp;			
		}
	
		
	 else {
		ModelResponsePattern mrp1 = new ModelResponsePattern();
		mrp1.setBody("model added failed - null");
		mrp1.setStatus("Failed");
		return mrp1;
		
		
	}

	}
	
	
	
}

