package com.easybuy.supermarket.service;

import java.util.List;

import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.responsePattern.CategoryResponsePattern;

public interface CategoryService {

	public List<category> getAllCategories();
	
	public CategoryResponsePattern catPat(category c);
}
