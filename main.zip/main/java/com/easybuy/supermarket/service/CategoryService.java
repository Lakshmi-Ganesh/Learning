package com.easybuy.supermarket.service;

import java.util.List;

import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.responsePattern.CategoryResponsePattern;
import com.easybuy.supermarket.vo.CategoryVO;

public interface CategoryService {

	public List<CategoryVO> getAllCategories();
	
	public CategoryResponsePattern catPat(CategoryVO c);
}
