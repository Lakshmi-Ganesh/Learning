package com.easybuy.supermarket.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.easybuy.supermarket.entity.UserLogin;
import com.easybuy.supermarket.entity.UserRegistration;
import com.easybuy.supermarket.repository.UserRepository;
import com.easybuy.supermarket.responsePattern.ResponsePattern;




@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

@Autowired
UserRepository userrepo;
	
	@Override
	public ResponsePattern registerUser(UserRegistration user) {
		
		if(user!= null) {
			
			Long autoUserId = System.currentTimeMillis();
			
			user.setUserId(autoUserId);
			ResponsePattern resp = new ResponsePattern();
			UserRegistration user1=userrepo.saveAndFlush( user);
			if(user1 != null) {
				
				resp.setStatus("Success");
				resp.setBody("Registration Done");
				resp.setUser(user1);
			}
			
			return resp;
			
			
		}
		
		else {
			ResponsePattern resperror = new ResponsePattern();
			resperror.setStatus("Failed");
			resperror.setBody("Something went wrong");
			
			return resperror;
		}
	
	}

	@Override
	public ResponsePattern loginUser(UserLogin login) {
		System.out.println(login);
		
		if(login != null) {
			
			ResponsePattern resp = new ResponsePattern();
			UserRegistration logindbcheck = userrepo.findByUserNameLogin(login.getfirstName(),login.getPassword());
			System.out.println(logindbcheck);
			if(logindbcheck != null) {
				
				resp.setStatus("success");
				resp.setBody("logedin successfully service");
				resp.setUser(logindbcheck);
			}
			else {
				
				resp.setStatus("Failed");
				resp.setBody("Something went wrong while login 2nd");
			}
			return resp;
			
		}
		
		else {
			ResponsePattern resp = new ResponsePattern();
			resp.setStatus("Failed");
			resp.setBody("Something went wrong while login when initial login itself fail");
			return resp;
		}
		
		
		
		
	}

	

}
