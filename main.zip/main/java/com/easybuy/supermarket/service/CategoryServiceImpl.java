package com.easybuy.supermarket.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.easybuy.supermarket.entity.brand;
import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.mapper.CategoryMapper;
import com.easybuy.supermarket.repository.CategoryRepository;
import com.easybuy.supermarket.responsePattern.CategoryResponsePattern;
import com.easybuy.supermarket.vo.CategoryVO;
@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	
	CategoryRepository categoryRep;
	
	@Autowired
	CategoryMapper categoryMapper;
	
	@Override
	public List<CategoryVO> getAllCategories() {
		
		List<CategoryVO> categoryVos = new ArrayList<>();
		List<category> cat = categoryRep.findAll();
		cat.forEach(c ->{
		CategoryVO categoryvo = new CategoryVO();
		categoryMapper.fromCategoryToCategoryVO(c, categoryvo);
		categoryVos.add(categoryvo);
			
		});
		
	return categoryVos;
	}

	@Override
	public CategoryResponsePattern catPat(CategoryVO catVO) {
		
		if(catVO!= null) {
			
			
			Long autocatId = System.currentTimeMillis();
			catVO.setCategoryId(autocatId);
			
			CategoryResponsePattern crp = new CategoryResponsePattern();
			category cat = new category();
			categoryMapper.fromCategoryVOToCategory(catVO, cat);
			 cat = categoryRep.saveAndFlush(cat);
			
			if(cat != null) {
				CategoryVO newCatVO = new CategoryVO();
				crp.setStatus("Success");
				crp.setBody("Successfully Category is added");
				categoryMapper.fromCategoryToCategoryVO(cat, newCatVO);
				crp.setCategory(cat);
				
				}
			return crp;
			
		} else {
			
			CategoryResponsePattern crp = new CategoryResponsePattern();
			crp.setStatus("Failed");
			crp.setBody("Unable to retrieve categories");
			return crp;
			
		}

	}

}
