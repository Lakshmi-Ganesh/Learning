package com.easybuy.supermarket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.easybuy.supermarket.entity.category;
import com.easybuy.supermarket.repository.CategoryRepository;
import com.easybuy.supermarket.responsePattern.CategoryResponsePattern;
@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	
	CategoryRepository categoryRep;
	
	
	
	@Override
	public List<category> getAllCategories() {
		// TODO Auto-generated method stub
	return categoryRep.findAll();
	}

	@Override
	public CategoryResponsePattern catPat(category cat) {
		
		if(cat!= null) {
			
			
			Long autocatId = System.currentTimeMillis();
			cat.setCategoryId(autocatId);
			
			CategoryResponsePattern crp = new CategoryResponsePattern();
			category cat1 = categoryRep.saveAndFlush(cat);
			
			if(cat1 != null) {
				
				crp.setStatus("Success");
				crp.setBody("Successfully Category is added");
				crp.setCategory(cat1);
				
				}
			return crp;
			
		} else {
			
			CategoryResponsePattern crp = new CategoryResponsePattern();
			crp.setStatus("Failed");
			crp.setBody("Unable to retrieve categories");
			return crp;
			
		}

	}

}
